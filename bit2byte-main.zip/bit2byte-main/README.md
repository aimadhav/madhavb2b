Problem Statement - A real time management system that allows workers to collaborate and work in remote offices. For reference Slack, Microsoft Teams, etc
Essential Feature : -
1. Message rooms ( for private and public conversation)
2. Login and Authentication system
3. Call feature (like huddle in slack)
4. Site should be hosted and link be provided ( can use Render or any other you like)
5. Github link must be provided and no code commits will be allowed after end time of hackathon
Additional Features:-
( more points ) ( can add one or more based on how much time you have)
1. can integrate AI features (open ended be creative)
2. white boards for meetings
3. your own feature anything you want (should be meaningful)
Judging Criteria :-
1. Having met the essential requirements is a must
2. More points for additional features
3. Great UI
4. Creativity and clean codes.
5. Responsiveness